package com.example.i_am_sorry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
